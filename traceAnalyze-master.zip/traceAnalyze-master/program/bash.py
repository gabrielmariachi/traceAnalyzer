#This is the bash script responsible to control the programs
#This file is used by the qtCreator to do everything in terms of control

import subprocess
#execute program:

subprocess.call(['C:\\Temp\\a b c\\Notepad.exe', 'C:\\test.txt'])